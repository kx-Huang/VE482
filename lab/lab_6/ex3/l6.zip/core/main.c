#include "interface.h"

int main(int argc, char *argv[]) {
  int ret = run(argc, argv);
  return ret;
}
